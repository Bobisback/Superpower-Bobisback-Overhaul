-- Rounding value for plot influence cost
INSERT INTO Defines(Name, Value) VALUES('PLOT_INFLUENCE_COST_VISIBLE_DIVISOR', 5);

INSERT INTO CustomModDbUpdates(Name, Value) VALUES('UI_CITY_EXPANSION', 1);
