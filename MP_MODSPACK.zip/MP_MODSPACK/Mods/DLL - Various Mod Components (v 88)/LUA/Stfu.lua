--
-- DO NOT DELETE THIS EVENT HANDLER!!!
--
-- DO NOT CHANGE THIS EVENT HANDLER UNLESS YOU REALLY KNOW WHAT YOU ARE DOING!!!
--
function OnDiplomacyStfuLeaveLeader(iResponseType)
  UI.RequestLeaveLeader()
end
GameEvents.DiplomacyStfuLeaveLeader.Add(OnDiplomacyStfuLeaveLeader)
--
-- END OF DIRE WARNING!!!
--
